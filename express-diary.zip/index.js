const express = require('express');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const app = express();
const pg = require('pg');
require('dotenv').config();
const port = process.env.port || 8080;

app.set('view engine', 'ejs');

const basePath = '/express-diary';
app.use(basePath, express.static('public'));

app.use(bodyParser.urlencoded({ extended: true}));
app.use(bodyParser.json());

//Method Override middlewear setup:
app.use(methodOverride('_method'));

//DATABASE

const db = new pg.Client({
    user: 'postgres',
    host: 'localhost',
    database: 'personal_diary',
    password: process.env.DB_PASSWORD,
    port: 5432,
})
db.connect()
  .then(() => console.log("PostgreSQL connected"))
  .catch(err => console.error("Connection error", err.stack));

//ROUTING

//Route for Homepage:
app.get(`${basePath}/`, (req, res) => {
    res.render('home');
});

//Route for About:
app.get(`${basePath}/about`, (req, res) => {
    res.render('about');
});

//Route for Diary:
app.get(`${basePath}/diary`, async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM diaries');
        res.render('diary', { data: result.rows });
    } catch (err) {
        console.error (err);
    }
});

//Route for the ADD Page Template:
app.get(`${basePath}/add`, (req, res) => {
    res.render('add');
})

//Route for Saving/Adding Diary:
app.post(`${basePath}/add-diary`, async (req, res) => {
    const { title, description, date } = req.body;
    try {
        await db.query('INSERT INTO diaries (title, description, date) VALUES ($1, $2, $3)',
    [title, description, date]);
     res.redirect(`${basePath}/diary`);
    } catch (err) {
        console.error(err);
    }
});

//Route for Post Details Page:
app.get(`${basePath}/diary/:id`, async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM diaries WHERE id = $1',
            [req.params.id]
        );
        res.render('details', { data: result.rows[0] });
    } catch (err) {
        console.error(err);
    }
});


//Route for the Edit page:
app.get(`${basePath}/diary/edit/:id`, async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM diaries WHERE id = $1',
            [req.params.id]
        );
        res.render('edit', { data: result.rows[0]});
    } catch (err) {
        console.error(err);
    }
});

//Edit Data:
app.put(`${basePath}/diary/edit/:id`, async (req, res) => {
    const { title, description, date } = req.body;
    try {
        await db.query('UPDATE diaries SET title = $1, description = $2, date = $3 WHERE id = $4',
            [title, description, date, req.params.id]
        );
        res.redirect(`${basePath}/diary`);
    } catch (err) {
        console.error(err);
    }
});

//Delete Data:
app.delete(`${basePath}/diary/delete/:id`, async (req, res) => {
    try {
        await db.query('DELETE FROM diaries WHERE id = $1', 
            [req.params.id]
        );
        res.redirect( `${basePath}/diary`);
    } catch(err) {
        console.error(err);
    }
});


//CREATE A SERVER:
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
})


